# Milestones

1. Foundation: upstream v1.6.1 and pinned engines cloned; architecture investigated;
   baseline hardware/emulator builds complete. Full test runs completed with documented
   baseline failures; see TESTING.md.
2. Identity: implemented first hardware-native organ/bass performance screen,
   branding, four parameter columns and bounded animation. Broader screen polish remains.
3. Organ/bass: implemented four new synthesis patches and direct knob assignments;
   audible-output, release, persistence and native/WASM parity checks passed.
   Desktop emulator verified. Roots Organ 0.2 audition approved as the starting point
   on 15 October 2026; preserve it and develop separate organ variants. Other
   presets still need musician approval; physical testing remains.
4. Extended instruments: bank 0.3 adds melodica, electric piano, piano chop, brass,
   skank, siren, FM bass, dub organ and an eight-piece kit. All require musician
   audition/refinement; acoustic realism is limited.
5. Dub effects: retained upstream effects; FX, delay and reverb now have native
   animated illustrations. Siren/dub organ expose delay send. Echo throws and
   deeper tape/spring refinements remain.
6. Presets: retained flash storage, full browsing and save/recall. Thirteen-sound HOME bank
   implemented; illustrated genre/category browsing remains.
7. Hardware optimisation: no physical device. Linker and target builds are necessary
   but cannot establish DAC quality, timing, controls, flashing or recovery on hardware.
8. Final polish: pending auditions and hardware validation.

This repository is an early instrument prototype, not the complete final vision.

User direction, 16 October 2026: ultimately remove all Felucca code. This is a
separate later rewrite, not satisfied by renaming the fork or hiding attribution.
Current work continues in the existing prototype to develop and validate sounds,
original UI design and interaction requirements. Research and first native UI
refinements are recorded in `docs/research/te-interface-study.md`.
