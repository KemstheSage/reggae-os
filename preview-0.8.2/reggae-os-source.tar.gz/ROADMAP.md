# Milestones

1. Foundation: upstream v1.6.1 and pinned engines cloned; architecture investigated;
   baseline hardware/emulator builds complete. Full test runs completed with documented
   baseline failures; see TESTING.md.
2. Identity: implemented first hardware-native organ/bass performance screen,
   branding, four parameter columns and bounded animation. Broader screen polish remains.
3. Organ/bass: implemented four new synthesis patches and direct knob assignments;
   audible-output, release, persistence and native/WASM parity checks passed.
   Desktop emulator verified. Roots Organ 0.2 audition approved as the starting point
   on 15 October 2026; preserve it and develop separate organ variants. Other
   presets still need musician approval; physical testing remains.
4. Extended instruments: bank 0.3 adds melodica, electric piano, piano chop, brass,
   skank, siren, FM bass, dub organ and an eight-piece kit. All require musician
   audition/refinement; acoustic realism is limited.
5. Dub effects: retained upstream effects; FX, delay and reverb now have native
   animated illustrations. Siren/dub organ expose delay send. Echo throws and
   deeper tape/spring refinements remain.
6. Presets: retained flash storage, full browsing and save/recall. Fifteen-sound HOME bank
   implemented; illustrated genre/category browsing remains.
7. Hardware optimisation: no physical device. Linker and target builds are necessary
   but cannot establish DAC quality, timing, controls, flashing or recovery on hardware.
8. Final polish: pending auditions and hardware validation.

This repository is an early instrument prototype, not the complete final vision.

User direction, 16 October 2026: ultimately remove all Felucca code. This is a
separate later rewrite, not satisfied by renaming the fork or hiding attribution.
Current work continues in the existing prototype to develop and validate sounds,
original UI design and interaction requirements. Research and first native UI
refinements are recorded in `docs/research/te-interface-study.md`.

Bank 0.5 adds a compact sampled roots trumpet and separate dub wail, jungle signal
and fast alarm candidates. Horn section layering remains future work. See
[bank 0.5](docs/reports/bank-0.5.md) for validation and limitations.

UI 0.4.0 begins the expanded workstation request: native note/drum editing and
song arrangement now share the REGGAE-OS layout. Existing four-part, four-source,
sixteen-section song playback is retained. Next: mixer, automation and project
management visual/workflow pass; full device timing and usability validation.

UI 0.4.1 simplifies the main pattern editor into sixteen large pads and a single
drum lane. Deep editing remains available. The next usability work remains
project saving/browsing, mixer and automation, with musician feedback on the pads.

UI 0.4.2 restores the previous piano-roll/drum-grid view at the musician's request
and introduces explicit add/replace/clear gestures for stopped note-step editing.

- UI 0.5.0: first SLOOP-style integration — HOME arm/first-note start, selected-track
  overdub, safe track handoff, T4 Roots Kit startup and performance-browser role,
  native recording/track indicators. Next: free-tempo take capture and live
  section-change recording; neither is implemented in this slice.

- UI 0.5.1: SEQ visual refinement and selected-track whole-piano-roll clear with
  a one-second EDIT+SEQ hold and SAVE undo. Further SLOOP integration is deferred
  while the current editing workflow is refined.
- UI 0.5.2: animated record character on SEQ/arrangement, driven by actual voice
  activity and sequencer position; clear-roll shortcut retained.

- UI 0.5.3: tabletop machine styling for the roll, drum grid and arranger; native
  pixel glyphs, responsive rotary indicators and existing character animation.

- UI 0.5.4: correct character/header spacing and keep help text inside the case;
  fit long labels within their allocated panels.

- UI 0.5.5: smaller performance-screen instrument/category names.

- UI 0.5.6: smaller sequencer headings and clear separation from tempo/status.

- UI 0.5.7: compact font for all four sequencer parameter labels and values.

- UI 0.5.8: compact shortcut hints; unified detail, automation, pattern tools,
  Euclid preview and cleanup screens. Project/mixer screens remain future work.

- UI 0.5.9: remove the sequencer hint background strip.

### UI 0.6.0 — live performance request

Implemented: four simultaneous level controls with mute/solo speaker characters;
sixteen punch-in pads including new SLOOP-derived gate and mono; direct
root/scale/chord/voicing controls with singing chord notes; optional credited
CC0 percussion pack through existing sample slots and the actual firmware
sampler. Jiant/Orchid/HiChord research and scope are documented. Not a wholesale
SLOOP port, not Orchid's proprietary engine, and not a new per-lane sampled
DRUM engine. Hardware and iPhone verification remain outstanding.

UI 0.6.1: persistent four-track MIXER page in the HOME cycle, four simultaneous
levels and keyboard mute/solo without holding a page button. Selected-track
pan/reverb controls remain on the following TRACK MIX page. Jiant influence
remains limited to original state-responsive mixer/chord characters; the
existing instrument illustrations have not undergone a further redesign.

UI 0.6.2: pan and reverb-send controls integrated into the themed mixer, with
four-track overview, selected-track outline and actual parameter indicators.
The old grey TRACK MIX view is no longer shown in the HOME cycle.

UI 0.6.3: unified mixer, permanent vertical volume faders, in-place four-track
LEVEL/PAN/REVERB knob assignments on C5/D5/E5. Second mixer page removed; normal
HOME cycle is MIXER → CLOCK → instrument. Mute/solo remain available throughout.

- UI 0.6.4: shared rack skin for remaining technical/system/storage screens;
  compact controls, retained graphs, native render sweep and hardware build.
  Alternate accessibility layouts and low-level diagnostics intentionally retained.

- UI 0.7.0: replace remaining normal stock page layouts with native workspaces,
  settings cards, record-sleeve browsing, label-printer naming, cable modulation,
  clock/chorus characters and matching dialogs/calibration. Preserve technical
  graphs and control semantics. Physical-device verification still outstanding.

### UI 0.7.1

- [x] Fifteen additional chord types with four-voice voicings and saved-project compatibility.
- [x] Searchable screenshot guide covering musical pages, settings and four-knob controls.
- [x] Native chord/audio and actual WASM input checks; hardware target build.
- [ ] Physical FM-1 and iPhone Safari verification.

- Pressure candidate: implement opt-in ADC reader, per-key light/firm calibration
  page and continuous punch-in depth mapping. Keep OFF default and stable release
  separate. Physical signal quality, ISR overhead and musical feel are still to
  be measured on the FM-1 before considering this a general-release feature.


### 31 October: workflow and processing request

0.7.7 DEV: punch-in first in FX, FX SENDS next, CHOPPER moved to EDIT;
drum-grid K4 edits the selected hit velocity. No saved page IDs or project format
changed. Not deployed or flashed.

Accepted remaining scope: parametric EQ and compression on all four tracks **and
master**; per-note length, velocity and repeats within the grid; consolidate
editing pages. The existing 3840-byte project payload has insufficient spare
space for the full requested processing state. A versioned storage extension
must preserve existing projects, survive interrupted writes and explicitly reject
capacity overflow before any slot is replaced. Individual note scheduling needs
tests for overlapping notes, retriggers, stop, section changes and hat/kick independence.


### 0.7.8 emulator-first preview

Implemented a parametric bell and linked compressor for T1–T4/master, independent
note lengths/repeats, and consolidated velocity/length/repeat/pitch grid editing.
FUNC compression extends persistence without reallocating flash; old format
imports default new controls to bypass. Audio and persistence tests cover the
shared firmware. Physical listening, CPU/timing validation and installation are
pending the musician returning home. Multi-band EQ is not implemented.

## UI 0.7.9 preview

- Implemented: 4 parametric bell bands on each track and master, edited from one page.
- Implemented: punch-in → EQ → compressor/timing → standard FX navigation, including SELECT.
- Removed slicer/chopper and pressure diagnostic pages from navigation; underlying saved settings retained.
- 0.7.8 FUNC imports into band 1; new FUNE saves carry four bands with bounded slot writes.
- Physical CPU/listening validation remains pending; no device flashing in this update.

## Riddim OS 0.8.0

- Renamed runtime branding and startup; three-second shared splash duration.
- 24 curated instruments; nine broader synth, wind and mallet additions.
- Replaced repetitive built-in trumpet/flute/sax sustain loops with finite faded samples.
- No hardware flashing; new bank awaits musician evaluation and physical CPU testing.

### 0.8.1 — grouped instruments and drum bank

Implemented presentation-only instrument grouping, five curated drum kits,
track-four kit browsing and a manual Mac browser installer with backup instructions.
Emulator/native audio and storage checks pass; hardware build fits. Next: musician
kit audition and a backed-up physical-device installation/test. No claim of physical
validation or acoustic drum realism.

## 0.8.2 acoustic drum candidate

See [drum sound design, compatibility and validation](docs/drums-0.8.2.md).
Four audition kits implemented; physical audition and installation remain pending.
