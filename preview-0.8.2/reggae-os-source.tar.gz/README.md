# Riddim OS

An experimental reggae instrument firmware for the **M-VAVE FM-1**, based on
[Felucca 1.6.1](https://github.com/hugelton/Felucca). The browser is a hardware
emulator running the same C synthesis and screen renderer, not the product.

**0.8.2 drum audition preview:** eight acoustic one-shots, revised Roots Kit,
Dusty HipHop, Soft LoFi and Ambient Perc. [Auditions](https://kemsthesage.github.io/reggae-os/preview-0.8.2/drums/)
· [Emulator](https://kemsthesage.github.io/reggae-os/preview-0.8.2/).
After Switch on, tap **Load new acoustic drum kits**. Without the optional pack,
these kits use synthesized fallback sounds. [Details, controls and limitations](docs/drums-0.8.2.md).
Hardware build verified; not yet flashed or physically tested. Existing beats and
approved organ/piano/bass sounds are preserved.

**0.8.1 preview:** 28 instruments grouped by type, a revised Roots Kit and four new
synthesized kits: Sub Machine, Circuit Kit, Break Kit and Hand Perc. Track four's
HOME browser now cycles through all five kits. Existing preset identities and
saved project formats are unchanged. Approved organ/piano/bass audio passes all
40 golden renders unchanged.

[Emulator](https://kemsthesage.github.io/reggae-os/preview-0.8.1/) ·
[Kit auditions and controls](https://kemsthesage.github.io/reggae-os/preview-0.8.1/guide/) ·
[Manual FM-1 update](https://kemsthesage.github.io/reggae-os/update-0.8.1/).
Read [backup and installation instructions](MANUAL_UPDATE.md) before flashing.
Hardware cross-build supported; this candidate has not been physically tested.

**0.8.0 / Riddim OS preview:** the library expands from 15 to 24 instruments.
New pads, leads, plucks, mallets and winds broaden it beyond reggae. The trumpet
now uses a 1.6-second source one-shot with a smooth fade; flute and sax use short
one-shots instead of repetitive sustain loops. These sampled notes end naturally
at their stored length (pitch shifts change duration); SYNTH BRASS sustains.
Approved organ, piano and bass preset settings are unchanged.

[Open Riddim OS](https://kemsthesage.github.io/reggae-os/preview-0.8.0/) ·
[Guide and auditions](docs/preview-0.8.0/index.html).
Startup displays Riddim OS for approximately three seconds. Felucca attribution
remains in credits and licence documentation. Existing repository URLs and storage
identities remain stable; each browser preview has isolated saves.

**0.7.9 emulator preview:** four parametric bell bands per track and master,
plus linked compression. FX order: punch-in, EQ, compressor/timing, standard FX.
Slicer/chopper and pressure-test pages are hidden. Individual note editing and
velocity colours remain available.
[Open preview](https://kemsthesage.github.io/reggae-os/preview-0.7.9/) ·
[Preview controls](docs/preview-0.7.9/index.html).
0.7.8 projects import with the original EQ in band 1; new processing saves require
0.7.9. Hardware cross-build and physical validation are separate; no flashing has
been performed. Each preview uses separate browser saves.

**Earlier 0.7.6 TEST candidate:** opt-in contact-pressure reader and calibration page,
direct pressure-controlled filters and an unchanged FX key layout. Sensing OFF at boot.
Raw readings reported on hardware; revised filter response still needs testing; public emulator
remains 0.7.4. [Trial instructions](docs/reports/pressure-hardware-test.md).

**UI 0.7.4 improves live workflow:** SAVE opens PROJECT; occupied-slot selection
arms LOAD for OCT+; PUNCH-IN remains open; preset browsing stays in the approved
bank plus user sounds. The reported duplicate-beat save issue has not reproduced
in emulated flash or physical-input tests; physical-device verification is still
needed. [Feedback report](docs/reports/ui-0.7.4.md).

**UI 0.7.3 adds individual note/drum velocities:** SEQ → NOTE VELOCITY.
K1 chooses the step, K2 the note, K3 the velocity, K4 individual/inherited.
Saved with PROJECT; shares the 128-entry automation budget. See [details](SEQUENCER.md#individual-note-velocities-ui-073).

**UI 0.7.2 adds AUTO chord voice leading:** SCL → CHORD GARDEN, K4 → AUTO.
Each track chooses nearby inversions as you play. See [usage and reset behaviour](SEQUENCER.md#automatic-chord-voice-leading-ui-072).

Sound bank 0.5 supplies **15 playable presets**, including organ, bass, reed
melodica, electric piano, piano chop, sampled roots trumpet, muted string skank, three dub/jungle sirens
and an eight-piece drum kit. Four-knob editing and animated 240 × 240 illustrations
run inside the firmware. It preserves the original engines,
MIDI paths, effects, sequencing and flash-backed user-preset system.

UI 0.5.0 begins the SLOOP-style recording integration: on HOME, arm with REC,
play the first note to start a loop at the set tempo, then overdub other tracks.
Fresh sessions start with organ, bass, trumpet and drums. Free-tempo capture and
live section recording remain planned. See [the song-making guide](SEQUENCER.md)
and [integration scope](docs/reports/ui-0.5.0.md).

UI 0.6.3 combines volume, pan and reverb in one mixer with permanent vertical faders,
alongside sixteen punch-in pads, a one-key chord garden
and an optional CC0 percussion pack. The shared hardware screen uses the tabletop
case and animated companions. [Controls and verification](docs/reports/ui-0.6.3.md).

**UI 0.7.0 redesigns the remaining page layouts**, rather than recolouring the
stock panels: SYSTEM DESK settings cards, record-sleeve libraries, LABEL PRESS
naming, a cable patchbay, a metronome character, chorus companions and the shared
instrument workbench. Hold **HOME** for Settings; ALGORITHM selects a tab,
PRESETS selects an item, OCT−/+ changes it, HOME closes it.
[Native screenshots and verification](docs/reports/ui-0.7.0.md).

**UI 0.7.1 adds 15 chord types**: suspended, sixth, add9, ninth, diminished,
augmented and minor-major colours. SCL → CHORD: K3 type, K4 voicing.
Read the [screenshot quick guide](https://kemsthesage.github.io/reggae-os/guide/)
for every musical page, how to reach it and all four knob assignments.
[Build and test report](docs/reports/ui-0.7.1.md).

**Early development build. Physical hardware and iPhone Safari are untested.**
The expanded sounds are audition candidates; musical refinement is ongoing.
See [TESTING.md](TESTING.md) for measured results and known limitations, and the
[bank 0.3 milestone report](docs/reports/bank-0.3.md) for screenshots and scope.

Sound bank 0.2 revises the registrations, dry organ articulation and plucked bass
envelopes following musician feedback. The listening brief is Big Ship, Faded Away
and Soldiers; these patches are audition candidates, not verified recreations.
See [SOUND_DESIGN.md](SOUND_DESIGN.md) for sources, exact changes and limitations.

## Sequence and arrange

UI 0.4.2 restores the piano roll and full drum grid. On the stopped note editor,
hold EDIT and play keys to add notes, hold REC and play to replace, or hold
EDIT + REC to clear the selected step.
Use SEQ for patterns and GLO for ARRANGE. Four parts can play a sixteen-section
song from four saved pattern sources, with per-track mutes and section repeats.
See [the song-making guide](SEQUENCER.md) for controls, saving and limits.

## Play on iPhone or desktop

Open **https://kemsthesage.github.io/reggae-os/** in Safari and tap **Switch on**.
This HTTPS deployment runs the same firmware WASM as the local emulator.
Actual iPhone audio and multitouch operation still need device verification.

## Play the local emulator

After [building](BUILDING.md):

```sh
python3 -m http.server 8790 --bind 127.0.0.1 --directory build/emu
```

Open **http://localhost:8790/** on the Mac and click **Switch on**.
Play the onscreen FM-1 keys (or the keyboard shortcuts shown below the panel).
Drag knobs upward/right, use the mouse wheel, or focus a knob and use arrow keys.

- Starts on Roots Organ. On HOME, PRESETS cycles the fifteen curated sounds.
- Horn knobs: tone, attack, decay and release. ROOTS TRUMPET uses three CC0 recorded notes.
- Sirens: DUB WAIL, JUNGLE SIGNAL (fall/length/echo/tone), FAST ALARM (range/rate/echo/tone).
- Organ knobs: registration, upper harmonics, rotary speed, drive.
- Bass knobs: cutoff, resonance, filter-envelope amount, drive. Use OCT− to play low notes.
- ROOTS KIT maps MIDI notes 36/38/39/42/46/45/37/56 to kick, snare, clap,
  closed/open hi-hat, tom, rim and bell. It is a playable kit, not a new sequencer.
- Fresh settings use the REGGAE palette throughout menus. Existing users can select
  REGGAE in MENU → PALETTE; saved preferences are retained.
- EDIT and ENV expose the existing deeper parameters; FX retains Felucca effects.
- SAVE retains the original user-preset workflow. Held HOME opens the menu;
  MENU ANIM OFF reduces performance-screen motion. Existing factory patches retain their original HOME controls.

The public GitHub Pages link above works independently of this Mac. An iPhone
cannot use the Mac's `localhost`; use the HTTPS deployment instead. The original
emulator already provides touch controls and a rearranged phone-sized hardware
panel. Actual mobile Safari audio, touch polyphony and interruptions still require testing.

## Architecture and project files

- [HARDWARE.md](HARDWARE.md): display, memory, controls, build status and installation/recovery references.
- [SOUND_DESIGN.md](SOUND_DESIGN.md): synthesis decisions and musical limitations.
- [UI_DESIGN.md](UI_DESIGN.md): shared firmware artwork and rendering budget.
- [TESTING.md](TESTING.md): baseline, audio, emulator and hardware evidence.
- [ROADMAP.md](ROADMAP.md): remaining milestones.
- `firmware/src/reggae_engines.c`: appended presets and adapters over unchanged upstream DSP.
- `firmware/src/reggae_ui.c`: native screen artwork and animation.
- `tools/reggae/`: table generation, tests and source/licence packaging.
- `.github/workflows/reggae.yml`: proposed CI build/test artifact workflow; not yet run on GitHub.

The original README is retained in [docs/FELUCCA_README.md](docs/FELUCCA_README.md).
Upstream source and engines are pinned on the `reggae-os` development branch.

## Licence and credit

GPL-3.0-only as a combined firmware. Preserve [LICENSE](LICENSE),
[LICENSING.md](LICENSING.md), [CREDITS.md](CREDITS.md), `LICENSES/`, fonts and sample
attributions. Felucca is by Leo Kuroshita / Hügelton Instruments and contributors.
Felucca-Engines remains an unchanged MIT submodule; its preset/descriptor prefixes
are reproduced with attribution in the REGGAE-OS adapter to preserve stored IDs.

When distributing builds, include complete corresponding source, including the
submodule's contents. `tools/reggae/package-emulator.sh` prepares that alongside
the emulator. No proprietary TE artwork or commercial recordings are included.
M-VAVE, FM-1 and Teenage Engineering product names belong to their respective owners;
this project is independent and has no claimed endorsement.

## UI refinement 0.3.1

The [OP-1 field / Sidekick study](docs/research/te-interface-study.md) informs an
original refinement of the hardware UI: musical labels, distinct control colours,
a brief enlarged parameter view and a parameter-linked bass filter illustration.
[Preview and implementation report](docs/reports/ui-0.3.1.md). Sound bank 0.3 and
the approved organ are unchanged. The future no-Felucca implementation is deferred.

## Artwork refinement 0.3.2

Smoother native curves and more developed organ/speaker artwork, with refined
piano, brass and siren housings. [Before/after and report](docs/reports/ui-0.3.2.md).
The physical screen remains 240 × 240; this is an artwork/rendering improvement.

UI 0.3.3 gives the melodica an expressive reed-player character: its mouth opens,
cheeks puff and breath appears with the sound. See the
[native rest/play comparison](docs/images/ui-0.3.3-melodica.png).

UI 0.3.4 replaces the human melodica player with an instrument creature and adds
siren/drum personalities, a clearer guitar, and characterful effects pages.
[See eight native screens](docs/images/ui-0.3.4-characters.png).

Sound bank 0.4 refines only melodica, brass, guitar, dub siren and drums.
The approved organ, piano and bass patches are protected by forty PCM hashes.
The changes are audition candidates; see [SOUND_DESIGN.md](SOUND_DESIGN.md).

UI 0.5.1 refines SEQ with an animated 45-label header and a reggae-themed palette.
On the stopped piano roll, hold EDIT then SEQ for one second to clear the track;
hold SAVE to undo. [Details](docs/reports/ui-0.5.1.md).
UI 0.5.2 adds a record character whose mouth reacts to notes and drum voices;
its groove marker follows the loop. The same character appears in the arranger.

UI **0.6.4** extends the REGGAE rack theme to technical editors, settings and
storage screens. [Screenshots, coverage and test results](docs/reports/ui-0.6.4.md).
Existing saved colour choices are respected; select COLOR → REGGAE for this skin.

UI 0.7.4 makes SAVE open complete PROJECT storage, distinguishes instrument-only
SOUNDS slots, adds a persistent PUNCH-IN FX page, and keeps standard browsing in
the approved bank plus user sounds. See [sequencer workflow](SEQUENCER.md).
