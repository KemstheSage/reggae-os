#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
set -eu
cd "$(dirname "$0")/../.."
mkdir -p build/reggae
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/test tests/reggae_test.c -lm
for preset in 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14; do
  for knob in -1 0 1 2 3; do
    build/reggae/test "$preset" "$knob" "build/reggae/p${preset}-k${knob}.wav" \
      "build/reggae/p${preset}-k${knob}.ppm"
  done
done > build/reggae/audio-report.txt
python3 - <<'PY'
import re
from pathlib import Path
lines=Path('build/reggae/audio-report.txt').read_text().splitlines()
for p in range(15):
    hashes=[re.search(r'hash=(\d+)',s).group(1) for s in lines if s.startswith(f'preset={p} ')]
    assert len(hashes)==5 and len(set(hashes))==5, (p,hashes)
print('PASS: fifteen presets, sixty knob variants: audible, finite, bounded, release to silence, distinct audio; preset recall.')
print(Path('build/reggae/audio-report.txt').read_text())
PY
python3 tools/reggae/check-protected.py
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/extended tests/reggae_extended.c -lm
for preset in 4 5 6 7 8 9 10 11 12 13 14; do
  build/reggae/extended "$preset" "build/reggae/extended-$preset.wav"
done > build/reggae/extended-report.txt
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/graphics tests/reggae_graphics.c -lm
build/reggae/graphics
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/style tests/reggae_style_demo.c -lm
for preset in 4 7 8 9 12; do
  build/reggae/style "$preset" "build/reggae/style-$preset.wav"
done > build/reggae/style-report.txt
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/siren-test tests/reggae_siren.c -lm
build/reggae/siren-test

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/arranger tests/reggae_arranger.c -lm
build/reggae/arranger
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/step-gestures tests/reggae_step_gestures.c -lm
build/reggae/step-gestures
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/live-record tests/reggae_live_record.c -lm
build/reggae/live-record
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/seq-character tests/reggae_seq_character.c -lm
build/reggae/seq-character

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/seq-menus tests/reggae_seq_menus.c -lm
build/reggae/seq-menus

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/performance tests/reggae_performance.c -lm
build/reggae/performance
python3 tools/reggae/percussion-pack.py

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/mixer-audio tests/reggae_mixer_audio.c -lm
build/reggae/mixer-audio

mkdir -p build/reggae/skin
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/skin-check tests/reggae_skin.c -lm
build/reggae/skin-check

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/workspace-test tests/reggae_workspace.c -lm
build/reggae/workspace-test

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/chords tests/reggae_chords.c -lm
build/reggae/chords
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/voice-leading tests/reggae_voice_leading.c -lm
build/reggae/voice-leading

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/note-velocity tests/reggae_note_velocity.c -lm
build/reggae/note-velocity

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/feedback tests/reggae_feedback.c -lm
build/reggae/feedback

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/pressure tests/reggae_pressure.c -lm
build/reggae/pressure

# Opt-in pressure: synthetic model/UI and mocked hardware-register lifecycle.
${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/pressure-input tests/reggae_pressure_input.c -lm
build/reggae/pressure-input
${CC:-cc} -O1 -o build/reggae/pressure-hal tests/reggae_pressure_hal.c
build/reggae/pressure-hal

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/pressure-filter tests/reggae_pressure_filter.c -lm
build/reggae/pressure-filter

${CC:-cc} ${REGGAE_TEST_CFLAGS:--O1} -ffp-contract=off -w -Ibuild/gen -Ifirmware/src -o build/reggae/workflow tests/reggae_workflow.c -lm
build/reggae/workflow
